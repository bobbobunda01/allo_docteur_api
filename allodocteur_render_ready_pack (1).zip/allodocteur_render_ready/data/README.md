# Base de connaissances

Place ici le fichier :

`kb_allodocteur_v3_complete.json`

Sur Render, tu peux aussi définir la variable d'environnement :

`ALLODOCTEUR_KB_PATH=data/kb_allodocteur_v3_complete.json`
